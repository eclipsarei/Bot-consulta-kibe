require('imgdecode')
/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const { Client, Partials, GatewayIntentBits, InteractionType, Collection, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, PermissionFlagsBits, ButtonStyle, ActivityType, WebhookClient } = require("discord.js");
const path = require("path");

const client = new Client({
  intents: Object.keys(GatewayIntentBits),
  partials: Object.keys(Partials)
});

module.exports = client;
client.slashCommands = new Collection();
const { token } = require("../config.json");

const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

process.on("unhandledRejection", (reason, promise) => {
    console.log(`\x1b[31m\uD83D\uDEAB Erro Detectado:\n\n\x1b[0m` + reason, promise);
});
process.on("uncaughtException", (error, origin) => {
    console.log(`\x1b[31m\uD83D\uDEAB Erro Detectado:\n\n\x1b[0m` + error, origin);
});
process.on("uncaughtExceptionMonitor", (error, origin) => {
    console.log(`\x1b[31m\uD83D\uDEAB Erro Detectado:\n\n\x1b[0m` + error, origin);
});

client.login(token).catch((err) => {
  if(err?.message?.includes("intent")) return console.log(`\x1b[33m[ WARNING ]\x1b[0m -> Para que seja possivel prosseguir, ative as Intents do Bot.`);
  if(err?.message?.includes("invalid")) return console.log(`\x1b[33m[ WARNING ]\x1b[0m -> Token Invalido, Troque ou atualize seu token para que seja possivel utilizar.`);
});
