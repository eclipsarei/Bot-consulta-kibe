/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const { ActionRowBuilder } = require("discord.js");

function getSaudacao() {
    const brazilTime = new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" });
    const hora = new Date(brazilTime).getHours();

    if (hora < 12) {
        return 'Bom dia';
    } else if (hora < 18) {
        return 'Boa tarde';
    } else {
        return 'Boa noite';
    }
}

module.exports = {
    getSaudacao
};
