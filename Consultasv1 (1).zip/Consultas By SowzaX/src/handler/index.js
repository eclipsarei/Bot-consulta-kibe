/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const fs = require("fs");
const path = require("path");


module.exports = async (client) => {
  const SlashsArray = [];

  const commandsFolder = path.join(__dirname, "../commands");
  const folders = fs.readdirSync(commandsFolder);

  for (const subfolder of folders) {
    const subfolderPath = path.join(commandsFolder, subfolder);
    const files = fs.readdirSync(subfolderPath);

    for (const file of files) {
      if (!file.endsWith(".js")) continue;

      const filePath = path.join(subfolderPath, file);
      const command = require(filePath);

      if (!command?.name) continue;

      client.slashCommands.set(command.name, command);
      SlashsArray.push(command);
    }
  }

  client.on("clientReady", async () => {

    client.guilds.cache.forEach(async (guild) => {
      await guild.commands.set(SlashsArray);
    });
  });

  client.on("guildCreate", async (guild) => {
    await guild.commands.set(SlashsArray);
  });
};
