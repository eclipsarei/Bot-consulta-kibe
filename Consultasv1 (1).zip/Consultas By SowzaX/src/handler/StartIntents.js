/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const config = require("../../config.json");

async function AtivarIntents() {

    await fetch('https://discord.com/api/v10/users/@me', {
        headers: {
            Authorization: `Bot ${config.token}`,
        },
    })
        .then((response) => {
            return response.json();
        })
        .then((data) => {
            const url = `https://discord.com/api/v9/applications/${data.id}`;
            fetch(url, {
                method: "PATCH",
                headers: {
                    Authorization: `Bot ${config.token}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    "flags": 8953856,
                    "custom_install_url": "https://discord.gg/h4CCtyXrvv",
                    "install_params": null
                }),
            });

        })
}

module.exports = {
    AtivarIntents
}
