const { JsonDatabase } = require("wio.db");

const perms = new JsonDatabase({ databasePath: "./src/db/perms.json" });
const config = new JsonDatabase({ databasePath: "./src/db/config.json" });

module.exports = {
    perms,
    config
};