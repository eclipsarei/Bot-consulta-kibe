const { ActivityType } = require("discord.js");
const { AtivarIntents } = require("../../handler/StartIntents.js");
const { JsonDatabase } = require("wio.db");
const { Client, GatewayIntentBits, Collection, Partials, PermissionFlagsBits, EmbedBuilder, } = require("discord.js");
console.clear();

module.exports = {
  name: "ready",
  run: async (client) => {
    console.clear();
    console.log(`[ 🚀 ] ${client.user.tag} Estou online!`);
    console.log(`[ 🚀 ] Versão: v2.0.0`);
    console.log(`[ 📖 ] Fui desenvolvido pelo SowzaX\n`);

    await updateClient(client);
    await AtivarIntents(client);
        
    client.user.setPresence({
        activities: [{ name: `customname`, type: ActivityType.Custom, state: `BlanK is coming back.` }],
        status: `dnd`,
    })
  },
};

async function updateClient(client) {
    const description = "**- <:coroa_emoji:1512274874394214591> | Projeto desenvolvido por @malincluido • @SowzaX\n- <:link_emoji:1512274872070438943> | https://discord.gg/exemplo • https://discord.gg/h4CCtyXrvv**";

    try {
        const response = await fetch(`https://discord.com/api/v9/applications/${client.user.id}`, {
            method: "PATCH",
            headers: {
                Authorization: `Bot ${client.token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ description, bio: description })
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);
    } catch (error) {
        console.error(`Erro ao atualizar bio do bot:`, error.message);
    }
}
