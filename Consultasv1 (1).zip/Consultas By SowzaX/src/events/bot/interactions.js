module.exports = {
    name: "interactionCreate",

    run: async (interaction, client) => {

        if(interaction.isChatInputCommand()){

            const cmd =
                client.slashCommands.get(interaction.commandName) ||
                client.slashCommandsVeinhu.get(interaction.commandName);

            if (!cmd) return;

            interaction.member = interaction.guild.members.cache.get(
                interaction.user.id
            );

            cmd.run(client, interaction);

        }

        if(interaction.isAutocomplete()){

            const command =
                client.slashCommands.get(interaction.commandName) ||
                client.slashCommandsVeinhu.get(interaction.commandName);

            if(!command) return;

            try{
                await command.autocomplete(interaction);
            }catch(err){}
        }

    }
}
// By SowzaX • BlanK Community