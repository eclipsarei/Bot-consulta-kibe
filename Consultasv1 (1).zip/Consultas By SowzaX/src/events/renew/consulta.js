/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const {
    ActionRowBuilder,
    AttachmentBuilder,
    ButtonBuilder,
    ButtonStyle,
    FileBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ContainerBuilder,
    SectionBuilder,
    TextDisplayBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    MessageFlags,
} = require("discord.js");
const { config } = require("../../db/index");

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {

        if (interaction.isStringSelectMenu() && interaction.customId === "painel_consultas") {
            const cargoVip = config.get("consultas.cargovip");

            if (!cargoVip || !interaction.member || !interaction.member.roles.cache.has(cargoVip)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`# Acesso restrito`)
                    )
                    .addSeparatorComponents(
                        new SeparatorBuilder()
                            .setDivider(true)
                            .setSpacing(SeparatorSpacingSize.Small)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`Somente usuários autorizados podem usar as consultas.`)
                    );

                return interaction.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                });
            }

            const tipo = interaction.values[0];

            const modal = new ModalBuilder()
                .setCustomId(`consulta_${tipo}`)
                .setTitle(`Consulta por ${tipo.toUpperCase()}`);

            const campo = new TextInputBuilder()
                .setCustomId("valor")
                .setLabel(`Digite o ${tipo.toUpperCase()}`)
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(campo));

            await interaction.showModal(modal);
        }

        if (interaction.isModalSubmit() && interaction.customId.startsWith("consulta_")) {
            const tipo = interaction.customId.replace("consulta_", "");
            const valor = interaction.fields.getTextInputValue("valor").trim();

            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const baseurl = config.get("config.baseurl");
            const key = config.get("config.key");
            const pastefyKey = config.get("config.pastefykey");
            const url = `${baseurl}/consulta/${tipo}/${encodeURIComponent(valor)}`;

            let res;
            let data;
            let erro = null;
            let resultado = null;

            try {
                res = await fetch(url, {
                    headers: { Authorization: `Bearer ${key}` },
                    signal: AbortSignal.timeout(180_000)
                });
                data = await res.json().catch(() => null);
            } catch (e) {
                erro = `conexao falhou: ${e.message}`;
            }

            if (!erro && !res.ok) {
                erro = `${res.status} ${data?.erro || data?.message || res.statusText}`;
            }

            if (!erro && !data) {
                erro = "resposta invalida";
            }

            if (!erro && data.estado === "pendente") {
                erro = `ainda rodando — job ${data.job}`;
            }

            if (!erro && data.saida) {
                resultado = data.saida;
            }

            if (!erro && !data.saida) {
                resultado = data;
            }

            if (erro) {
                const containerErro = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`# Erro na consulta`)
                    )
                    .addSeparatorComponents(
                        new SeparatorBuilder()
                            .setDivider(true)
                            .setSpacing(SeparatorSpacingSize.Small)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(erro)
                    );

                return interaction.editReply({
                    components: [containerErro],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const texto = typeof resultado === "string" ? resultado : JSON.stringify(resultado, (k, v) => k === "retrato" ? undefined : v, 2);
            const conteudo = `Buscar ${tipo.toUpperCase()} : ${valor}\n\n${texto}`;

            let pasteUrl = null;

            try {
                const pasteRes = await fetch("https://pastefy.app/api/v2/paste", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        ...(pastefyKey ? { Authorization: `Bearer ${pastefyKey}` } : {})
                    },
                    body: JSON.stringify({
                        title: `Resultado — ${tipo.toUpperCase()}`,
                        content: conteudo,
                        visibility: "UNLISTED",
                        type: "PASTE"
                    }),
                    signal: AbortSignal.timeout(30_000)
                });
                const pasteData = await pasteRes.json().catch(() => null);

                if (pasteRes.ok && pasteData?.paste?.id) {
                    pasteUrl = `https://pastefy.app/${pasteData.paste.id}`;
                }
            } catch (e) {
                pasteUrl = null;
            }

            const icone = interaction.guild?.iconURL({ extension: "png" }) || client.user.displayAvatarURL({ extension: "png" });
            const arquivosResultado = [];

            const containerResultado = new ContainerBuilder()
                .addSectionComponents(
                    new SectionBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder()
                                .setContent(`# Resultado — ${tipo.toUpperCase()}`),
                            new TextDisplayBuilder()
                                .setContent(`**Termo:** \`${valor}\``)
                        )
                        .setThumbnailAccessory(
                            new ThumbnailBuilder()
                                .setURL(icone)
                        )
                )
                .addSeparatorComponents(
                    new SeparatorBuilder()
                        .setDivider(true)
                        .setSpacing(SeparatorSpacingSize.Small)
                );

            if (pasteUrl) {
                containerResultado.addActionRowComponents(
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setStyle(ButtonStyle.Link)
                            .setLabel("Abrir resultado")
                            .setURL(pasteUrl)
                    )
                );
            }

            if (!pasteUrl) {
                arquivosResultado.push(new AttachmentBuilder(Buffer.from(conteudo, "utf-8"), { name: "resultado.txt" }));

                containerResultado
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`Não consegui gerar o link, o resultado está no arquivo abaixo.`)
                    )
                    .addFileComponents(
                        new FileBuilder()
                            .setURL("attachment://resultado.txt")
                    );
            }

            const perfis = Array.isArray(data.parentes) ? data.parentes : [];
            const arquivos = [];

            const containerFotos = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder()
                        .setContent(`# Foto`)
                );

            for (let i = 0; i < perfis.length && arquivos.length < 10; i++) {
                if (!perfis[i] || !perfis[i].retrato) {
                    continue;
                }

                const buffer = Buffer.from(String(perfis[i].retrato).replace(/^data:image\/\w+;base64,/, ""), "base64");
                const nome = `retrato_${arquivos.length + 1}.${buffer[0] === 0xff ? "jpg" : "png"}`;

                arquivos.push(new AttachmentBuilder(buffer, { name: nome }));

                containerFotos.addSeparatorComponents(
                    new SeparatorBuilder()
                        .setDivider(true)
                        .setSpacing(SeparatorSpacingSize.Small)
                );

                containerFotos.addMediaGalleryComponents(
                    new MediaGalleryBuilder()
                        .addItems(
                            new MediaGalleryItemBuilder()
                                .setURL(`attachment://${nome}`)
                        )
                );
            }

            try {
                await interaction.user.send({
                    components: [containerResultado],
                    files: arquivosResultado,
                    flags: MessageFlags.IsComponentsV2
                });

                if (arquivos.length > 0) {
                    await interaction.user.send({
                        components: [containerFotos],
                        files: arquivos,
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            } catch (e) {
                const containerPv = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`Não consegui enviar no seu privado. Libere suas mensagens diretas e tente de novo.`)
                    );

                return interaction.editReply({
                    components: [containerPv],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const containerOk = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder()
                        .setContent(`Consulta realizada com sucesso`)
                );

            await interaction.editReply({
                components: [containerOk],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};