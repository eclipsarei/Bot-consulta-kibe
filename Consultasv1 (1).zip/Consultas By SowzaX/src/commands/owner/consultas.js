/*

    * Bot desenvolvido por SowzaX 
    * Suporte: https://discord.gg/h4CCtyXrvv
    * deixa os creditos ae comedia

*/

const {
  ApplicationCommandType,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  MessageFlags
} = require("discord.js")
const { perms } = require("../../db/index");

module.exports = {
  name: "painel-consulta",
  description: "Enviar o Painel de Consulta nesse canal",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (interaction.user.id !== perms.get(`${interaction.user.id}`)) {
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder()
                    .setContent(`# Acesso negado\nVocê não tem permissão para usar este comando!`)
            );

        return interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        });
    }

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder()
          .setContent(`# Painel Consultas\nSelecione uma opção no menu.`)
      )
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL("https://raw.githubusercontent.com/SowzaX/icons-utils/main/image/729c17e4b55ea11587f4da60265de717.jpg")
        )
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId("painel_consultas")
            .setPlaceholder("Selecione uma função")
            .addOptions(
              { label: "CPF", description: "Consulta completa por CPF", value: "cpf", emoji: "<:lupa:1552077088805101641>" },
              { label: "NOME", description: "Consulta por nome completo", value: "nome", emoji: "<:lupa:1552077088805101641>" },
              { label: "TELEFONE", description: "Consulta por telefone com DDD", value: "telefone", emoji: "<:lupa:1552077088805101641>" },
              { label: "FOTO", description: "Consulta por CPF (fotos)", value: "foto", emoji: "<:lupa:1552077088805101641>" },
              { label: "CNPJ", description: "Consulta por CNPJ", value: "cnpj", emoji: "<:lupa:1552077088805101641>" },
              { label: "EMAIL", description: "Consulta por email", value: "email", emoji: "<:lupa:1552077088805101641>" },
              { label: "IP", description: "Consulta por IP", value: "ip", emoji: "<:lupa:1552077088805101641>" },
              { label: "CEP", description: "Consulta por CEP", value: "cep", emoji: "<:lupa:1552077088805101641>" }
            )
        )
      );

    return interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
  }
}