const {
    ApplicationCommandType,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    UserSelectMenuBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    SectionBuilder
} = require("discord.js")
const { JsonDatabase } = require("wio.db")
const { perms } = require("../../db/index");
const dono = new JsonDatabase({ databasePath: "./config.json" })

function buildPermsTexto() {
    const entries = perms.all();
    if (!entries.length) return { texto: `*Nenhum usuário possui permissão no momento.*`, entries };
    let texto = '';
    entries.map((entry, index) => { texto += `  - -# ${index + 1} - <@${entry.data}>\n`; });
    return { texto, entries };
}

function buildMainContainer(interaction) {
    const { texto, entries } = buildPermsTexto();

    const container = new ContainerBuilder()
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# \`💻\` ${interaction.guild.name} - Perms`)
        )
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`- **Utilize as opções abaixo para definir quais usuários possuem permissão para administrar o sistema do seu bot.**`)
        )
        .addSeparatorComponents(
            new SeparatorBuilder().setSpacing('Small')
        )
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`- **Informações de permissões:**\n  - -# **Usuários com permissões:** \`${entries.length}/25\`\n ${texto}`)
        )
        .addSeparatorComponents(
            new SeparatorBuilder().setSpacing('Small')
        )
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`-# **Controles do sistema**`)
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setStyle(2)
                    .setCustomId(`add_perm`)
                    .setEmoji(`<:_add_emoji:1502773260117610527>`)
                    .setLabel(`Adicionar Usuário`),
                new ButtonBuilder()
                    .setStyle(2)
                    .setCustomId(`sub_perm`)
                    .setEmoji(`<:minus:1542565953144098816>`)
                    .setLabel(`Remover Usuário`)
            )
        )

    return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function buildAddSelectContainer(interaction) {
    const container = new ContainerBuilder()
        .addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# \`💻\` ${interaction.guild.name} - Add Perms`),
                    new TextDisplayBuilder().setContent(`- **Utilize as opção abaixo para definir um usuário com perm.**`)
                )
                .setButtonAccessory(
                    new ButtonBuilder().setCustomId("voltar_perm").setEmoji(`<:_back_emoji:1482930921710686381>`).setStyle(2)
                )
        )
        .addSeparatorComponents(
            new SeparatorBuilder().setSpacing('Small').setDivider(true)
        )
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`-# **Selecione um user**`)
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new UserSelectMenuBuilder()
                    .setCustomId(`select_add_perm`)
                    .setPlaceholder(`Selecione o usuário...`)
                    .setMinValues(1)
                    .setMaxValues(1)
            )
        )

    return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

async function buildRemoveSelectContainer(client, interaction) {
    const { entries } = buildPermsTexto();

    if (!entries.length) return null;

    const options = [];
    for (const entry of entries) {
        let label = entry.data;
        const cached = client.users.cache.get(entry.data);
        if (cached) {
            label = cached.username;
        } else {
            try {
                const user = await client.users.fetch(entry.data);
                label = user.username;
            } catch {
                label = `Usuário desconhecido (${entry.data})`;
            }
        }
        options.push(
            new StringSelectMenuOptionBuilder()
                .setLabel(label)
                .setValue(`${entry.data}`)
        );
    }

    const container = new ContainerBuilder()
        .addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# \`💻\` ${interaction.guild.name} - Add Perms`),
                    new TextDisplayBuilder().setContent(`- **Utilize as opção abaixo para definir um usuário que perderá perm do bot.**`)
                )
                .setButtonAccessory(
                    new ButtonBuilder().setCustomId("voltar_perm").setEmoji(`<:_back_emoji:1482930921710686381>`).setStyle(2)
                )
        )
        .addSeparatorComponents(
            new SeparatorBuilder().setSpacing('Small')
        )
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`-# **Selecione um user**`)
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId(`select_sub_perm`)
                    .setPlaceholder(`Selecione o usuário...`)
                    .addOptions(options)
            )
        )

    return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function buildExpiredContainer() {
    const container = new ContainerBuilder()
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# Sessão expirada\nUse \`/perms\` novamente para gerenciar as permissões.`)
        )

    return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

module.exports = {
    name: "perms",
    description: "Gerenciar perms do seu bot",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== dono.get(`owner`)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# Acesso negado`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing('Small').setDivider(true)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Você não tem permissão para usar este comando!`)
                );

            return interaction.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });
        }

        await interaction.reply({
            ...buildMainContainer(interaction),
            flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        });

        const msg = await interaction.fetchReply();

        const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user.id === interaction.user.id,
            time: 5 * 60 * 1000
        });

        collector.on("collect", async (i) => {
            if (i.customId === "add_perm") {
                return i.update(buildAddSelectContainer(interaction));
            }

            if (i.customId === "sub_perm") {
                await i.deferUpdate();

                const removeContainer = await buildRemoveSelectContainer(client, interaction);
                if (!removeContainer) {
                    return i.followUp({
                        content: `\`🔴\` Nenhum usuário possui permissão.`,
                        flags: MessageFlags.Ephemeral
                    });
                }
                return i.editReply(removeContainer);
            }

            if (i.customId === "voltar_perm") {
                return i.update(buildMainContainer(interaction));
            }

            if (i.customId === "select_add_perm" && i.isUserSelectMenu()) {
                const selectedId = i.values[0];

                if (perms.has(`${selectedId}`)) {
                    return i.reply({
                        content: `\`🔴\` Este usuário ja possui permissão.`,
                        flags: MessageFlags.Ephemeral
                    });
                }

                perms.set(`${selectedId}`, selectedId);
                return i.update(buildMainContainer(interaction));
            }

            if (i.customId === "select_sub_perm" && i.isStringSelectMenu()) {
                const selectedId = i.values[0];

                if (!perms.get(`${selectedId}`)) {
                    return i.reply({
                        content: `\`🔴\` Nenhum usuário possui permissão.`,
                        flags: MessageFlags.Ephemeral
                    });
                }

                perms.delete(`${selectedId}`);
                return i.update(buildMainContainer(interaction));
            }
        });

        collector.on("end", () => {
            msg.edit(buildExpiredContainer()).catch(() => {});
        });
    }
}